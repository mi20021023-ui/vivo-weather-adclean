package com.lwb.weatherclean;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.TextView;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.util.Locale;

/** Best-effort, UI-only ad container suppression for vivo Weather. */
public final class WeatherAdClean implements IXposedHookLoadPackage {
    private static final String TARGET = "com.vivo.weather";
    private static final String[] AD_TOKENS = {
        "adview", "ad_view", "adcontainer", "ad_container", "nativead", "native_ad",
        "feedad", "feed_ad", "advert", "advertisement", "adsdk", "bannerad", "banner_ad",
        "thirdnativead", "life_banner_ad"
    };

    @Override public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;
        XposedBridge.log("WeatherAdClean: loaded for " + lpparam.packageName);
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    if (!(param.thisObject instanceof Activity)) return;
                    final Activity activity = (Activity) param.thisObject;
                    try {
                        View decor = activity.getWindow() == null ? null : activity.getWindow().getDecorView();
                        if (decor != null) decor.postDelayed(new Runnable() {
                            @Override public void run() {
                                try {
                                    if (!activity.isFinishing()) cleanTree(activity.getWindow().getDecorView(), activity);
                                } catch (Throwable t) { XposedBridge.log("WeatherAdClean sweep: " + t); }
                            }
                        }, 350);
                    } catch (Throwable t) { XposedBridge.log("WeatherAdClean resume: " + t); }
                }
            });
        } catch (Throwable t) { XposedBridge.log("WeatherAdClean hook failed: " + t); }
    }

    private static void cleanTree(View view, Activity activity) {
        if (view == null) return;
        if (isAdView(view, activity)) {
            ViewParent parent = view.getParent();
            if (parent instanceof ViewGroup) {
                ViewGroup group = (ViewGroup) parent;
                try {
                    // Remove only views with strong ad-related class/resource identifiers.
                    group.removeView(view);
                    XposedBridge.log("WeatherAdClean removed: " + view.getClass().getName());
                    return;
                } catch (Throwable ignored) { view.setVisibility(View.GONE); }
            } else {
                view.setVisibility(View.GONE);
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = group.getChildCount() - 1; i >= 0; i--) cleanTree(group.getChildAt(i), activity);
        }
    }

    private static boolean isAdView(View view, Activity activity) {
        String className = view.getClass().getName().toLowerCase(Locale.ROOT);
        if (hasAdToken(className)) return true;
        try {
            int id = view.getId();
            if (id != View.NO_ID) {
                String name = activity.getResources().getResourceEntryName(id).toLowerCase(Locale.ROOT);
                if (hasAdToken(name)) return true;
            }
        } catch (Throwable ignored) {}
        // Avoid matching generic text such as “广告” alone; only use explicit SDK marker labels.
        if (view instanceof TextView) {
            CharSequence text = ((TextView) view).getText();
            if (text != null) {
                String s = text.toString().trim().toLowerCase(Locale.ROOT);
                if (s.equals("广告") || s.equals("广告·") || s.equals("ad") || s.equals("sponsored")) {
                    ViewParent p = view.getParent();
                    if (p instanceof View && hasAdToken(((View)p).getClass().getName().toLowerCase(Locale.ROOT))) return true;
                }
            }
        }
        return false;
    }
    private static boolean hasAdToken(String s) {
        for (String token : AD_TOKENS) if (s.contains(token)) return true;
        return false;
    }
}
