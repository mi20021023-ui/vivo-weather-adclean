# vivo 天气详情去广告（LSPosed）

目标包名：`com.vivo.weather`。根据用户提供的 vivo 天气 9.3.3.00 APK 中可见的广告 SDK/类名线索制作。

## 构建

项目通过 GitHub Actions 构建：上传本项目到 GitHub 仓库，在 Actions 中运行 `Build vivo Weather AdClean LSPosed Module`，完成后下载 `vivo-weather-adclean-debug` artifact 内的 APK。

## 安装启用

1. 安装生成的 `app-debug.apk`。
2. 在 LSPosed 管理器中启用“vivo天气详情去广告”。
3. 作用域只勾选“天气”（`com.vivo.weather`）。
4. 强行停止天气 App 后重新打开，进入天气详情页测试。

## 注意

这是第一版的通用 UI 容器过滤实现，按类名和资源 ID 中明确的广告标记尝试移除广告视图。不同页面可能使用混淆类名或动态布局，因此不能保证一次就移除所有信息流广告；如果广告仍存在，请提供广告出现时的截图，后续可针对实际容器精确调整。模块不修改原始天气 APK，也不主动拦截网络。
